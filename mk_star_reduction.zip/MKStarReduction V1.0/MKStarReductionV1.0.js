#engine v8

#feature-id    Utilities > MK Star Reduction
#feature-icon  mk_star_reduction.svg
#feature-info  Star Reduction using Transfer Method.

#include <pjsr/FrameStyle.jsh>
#include <pjsr/TextAlign.jsh>
#include <pjsr/StdButton.jsh>
#include <pjsr/StdIcon.jsh>
#include <pjsr/StdCursor.jsh>

function buildExpression( S, starlessId, targetId )
{
   var T = (targetId && targetId !== "") ? targetId : "$T";
   return "min(" + T + ", ~((~mtf(~" + S.toFixed(2) +
          "," + T + ")/~mtf(~" + S.toFixed(2) +
          "," + starlessId +
          "))*~" + starlessId + "))";
}

//---------------------------------------------------------
// ScrollControl Class (Embedded Viewer)
//---------------------------------------------------------
var ScrollControl = class extends ScrollBox
{
   constructor( parent )
   {
      super( parent );

      this.autoScroll = true;
      this.tracking = true;

      this.displayImage = null;
      this.dragging = false;
      this.dragOrigin = new Point( 0, 0 );

      this.viewport.cursor = new Cursor( StdCursor_OpenHand );

      this.viewport.onResize = () =>
      {
         this.initScrollBars();
      };

      this.onHorizontalScrollPosUpdated = x =>
      {
         this.viewport.update();
      };

      this.onVerticalScrollPosUpdated = y =>
      {
         this.viewport.update();
      };

      this.viewport.onMousePress = ( x, y, button, buttons, modifiers ) =>
      {
         this.viewport.cursor = new Cursor( StdCursor_ClosedHand );
         this.dragOrigin.x = x;
         this.dragOrigin.y = y;
         this.dragging = true;
      };

      this.viewport.onMouseMove = ( x, y, buttons, modifiers ) =>
      {
         if ( this.dragging )
         {
            this.scrollPosition = new Point( this.scrollPosition ).translatedBy(
               this.dragOrigin.x - x,
               this.dragOrigin.y - y
            );
            this.dragOrigin.x = x;
            this.dragOrigin.y = y;
         }
      };

      this.viewport.onMouseRelease = ( x, y, button, buttons, modifiers ) =>
      {
         this.viewport.cursor = new Cursor( StdCursor_OpenHand );
         this.dragging = false;
      };
      this.viewport.onMouseWheel = ( x, y, delta, buttons, modifiers ) =>
      {
         if ( this.parent && this.parent.onPreviewWheelZoom )
            this.parent.onPreviewWheelZoom( delta, x, y, modifiers );
      };
      this.viewport.onPaint = ( x0, y0, x1, y1 ) =>
      {
         let g = new Graphics( this.viewport );
         let result = this.getImage();

         if ( result == null )
         {
            g.fillRect( x0, y0, x1, y1, new Brush( 0xff000000 ) );
         }
         else
         {
            result.selectedRect = (new Rect( x0, y0, x1, y1 )).translated( this.scrollPosition );
            g.drawBitmap( x0, y0, result.render() );
            result.resetRectSelection();
         }

         g.end();
      };

      this.initScrollBars();
   }

   getImage()
   {
      return this.displayImage;
   }

   doUpdateImage( image )
   {
      this.displayImage = image;
      this.initScrollBars();
      this.viewport.update();
   }

   initScrollBars()
   {
      let image = this.getImage();
      if ( image == null || image.width <= 0 || image.height <= 0 )
      {
         this.setHorizontalScrollRange( 0, 0 );
         this.setVerticalScrollRange( 0, 0 );
      }
      else
      {
         this.setHorizontalScrollRange( 0, Math.max( 0, image.width - this.viewport.width ) );
         this.setVerticalScrollRange( 0, Math.max( 0, image.height - this.viewport.height ) );
      }
      this.viewport.update();
   }
};

//---------------------------------------------------------
// Dialog
//---------------------------------------------------------
var StarReductionDialog = class extends Dialog
{
   constructor()
   {
      super();

      this.windowTitle = "MK Star Reduction";
      this.userResizable = true;

      this.uiStrength = 0.30;
      this.previewBaseImage = null;

      this.windows = ImageWindow.windows;
      var viewIds = [];
      for ( var i = 0; i < this.windows.length; ++i ) {
         viewIds.push(this.windows[i].mainView.id);
      }

      //------------------------------------------------------
      // Custom Title Header
      //------------------------------------------------------
      this.titleLabel = new Label(this);
      this.titleLabel.text = "MK Star Reduction - Version 1.0";
      this.titleLabel.textAlignment = TextAlign_Center | TextAlign_VertCenter;
      this.titleLabel.styleSheet = "QLabel { background-color: #1A365D; color: #FFFFFF; font-weight: bold; font-size: 12pt; padding: 6px; }";

      //------------------------------------------------------
      // Description & Copyright Box
      //------------------------------------------------------
      this.descBox = new TextBox(this);
      this.descBox.readOnly = true;
      this.descBox.text =
         "This script performs precise star reduction using the Transfer Method. " +
         "It allows for an intuitive, live-previewed reduction of star intensity.\n\n" +
         "© Mohammed Khalifa (mhk.astro) - 2026";
      this.descBox.minHeight = 90;
      this.descBox.maxHeight = 90;
      this.descBox.styleSheet = "QTextEdit { background-color: #EAEAEA; color: #000000; }";

      //------------------------------------------------------
      // Instructions / Guide Box
      //------------------------------------------------------
      this.guideBox = new GroupBox(this);
      this.guideBox.title = "Instructions";
      this.guideBox.sizer = new VerticalSizer;
      this.guideBox.sizer.margin = 6;
      this.guideBox.sizer.spacing = 3;

      var guideLines = [
         "1. Select your image with stars and starless image.",
         "2. Choose whether to replace target or create a new image.",
         "3. Check 'Show Preview' if needed.",
         "4. Adjust Reduction Strength and click 'Refresh Preview' to update changes.",
         "5. Apply."
      ];

      for (var i = 0; i < guideLines.length; ++i) {
         var guideText = new Label(this.guideBox);
         guideText.text = guideLines[i];
         this.guideBox.sizer.add(guideText);
      }

      //------------------------------------------------------
      // Comboboxes
      //------------------------------------------------------

      // Stars image selection
      this.starsLabel = new Label(this);
      this.starsLabel.text = "Image with stars:";
      this.starsLabel.textAlignment = TextAlign_Right|TextAlign_VertCenter;
      this.starsLabel.minWidth = 110;

      this.starsCombo = new ComboBox(this);
      for ( var i = 0; i < viewIds.length; ++i )
         this.starsCombo.addItem( viewIds[i] );

      for ( let i = 0; i < viewIds.length; ++i ) {
          if ( viewIds[i].toLowerCase().indexOf("starless") === -1 ) {
              this.starsCombo.currentItem = i;
              break;
          }
      }

      this.starsCombo.onItemSelected = () => this.refreshPreview();

      // Starless image selection
      this.starlessLabel = new Label(this);
      this.starlessLabel.text = "Starless image:";
      this.starlessLabel.textAlignment = TextAlign_Right|TextAlign_VertCenter;
      this.starlessLabel.minWidth = 110;

      this.starlessCombo = new ComboBox(this);
      for ( var i = 0; i < viewIds.length; ++i )
         this.starlessCombo.addItem( viewIds[i] );

      let starlessFound = false;
      for ( let i = 0; i < viewIds.length; ++i ) {
          if ( viewIds[i].toLowerCase().indexOf("starless") !== -1 ) {
              this.starlessCombo.currentItem = i;
              starlessFound = true;
              break;
          }
      }

      if (!starlessFound && viewIds.length > 1) {
          this.starlessCombo.currentItem = 1;
      }

      this.starlessCombo.onItemSelected = () => this.refreshPreview();

      //------------------------------------------------------
      // Slider Controls
      //------------------------------------------------------
      this.sliderLabel = new Label(this);
      this.sliderLabel.text = "Reduction Strength:";
      this.sliderLabel.textAlignment = TextAlign_Right|TextAlign_VertCenter;
      this.sliderLabel.minWidth = 110;

      this.slider = new Slider(this);
      this.slider.minValue = 0;
      this.slider.maxValue = 90;
      this.slider.value = 30;

      this.valueEdit = new Edit(this);
      this.valueEdit.minWidth = 55;
      this.valueEdit.maxWidth = 55;
      this.valueEdit.text = format("%.2f", this.uiStrength);

      this.slider.onValueUpdated = v =>
      {
         this.uiStrength = v / 100.0;
         var newText = format("%.2f", this.uiStrength);
         if (this.valueEdit.text !== newText) {
             this.valueEdit.text = newText;
         }
      };

      this.valueEdit.onEditCompleted = () =>
      {
         var val = parseFloat(this.valueEdit.text);
         if (isNaN(val)) val = 0.0;
         else if (val < 0.0) val = 0.0;
         else if (val > 1.0) val = 1.0;

         this.uiStrength = val;
         this.valueEdit.text = format("%.2f", this.uiStrength);
         this.slider.value = Math.round(this.uiStrength * 100);
      };

      //------------------------------------------------------
      // Output Options Group (Create New vs Replace)
      //------------------------------------------------------
      this.outputGroupBox = new GroupBox(this);
      this.outputGroupBox.title = "Output Mode";
      this.outputGroupBox.sizer = new HorizontalSizer;
      this.outputGroupBox.sizer.margin = 6;
      this.outputGroupBox.sizer.spacing = 15;

      this.replaceCheckBox = new CheckBox(this.outputGroupBox);
      this.replaceCheckBox.text = "Replace target image";
      this.replaceCheckBox.checked = true;

      this.createNewCheckBox = new CheckBox(this.outputGroupBox);
      this.createNewCheckBox.text = "Create new image";
      this.createNewCheckBox.checked = false;

      // Make them mutually exclusive like radio buttons
      this.replaceCheckBox.onCheck = checked => {
         if (checked) this.createNewCheckBox.checked = false;
         else if (!this.createNewCheckBox.checked) this.replaceCheckBox.checked = true;
      };

      this.createNewCheckBox.onCheck = checked => {
         if (checked) this.replaceCheckBox.checked = false;
         else if (!this.replaceCheckBox.checked) this.createNewCheckBox.checked = true;
      };

      this.outputGroupBox.sizer.add(this.replaceCheckBox);
      this.outputGroupBox.sizer.add(this.createNewCheckBox);

      //------------------------------------------------------
      // Preview Group Box (Fully Contained)
      //------------------------------------------------------
      this.previewGroupBox = new GroupBox( this );
      this.previewGroupBox.title = "Live Preview";
      this.previewGroupBox.sizer = new VerticalSizer;
      this.previewGroupBox.sizer.margin = 8;
      this.previewGroupBox.sizer.spacing = 6;

      this.showPreviewCheckBox = new CheckBox( this.previewGroupBox );
      this.showPreviewCheckBox.text = "Show Preview";
      this.showPreviewCheckBox.checked = false;
      this.showPreviewCheckBox.onCheck = checked =>
      {
         this.previewControl.visible = checked;
         this.zoomSizer.visible = checked;

         if ( checked ) {
            this.refreshPreview();
         }

         this.adjustToContents();
         this.setFixedSize();
      };

      this.zoomLabel = new Label( this.previewGroupBox );
      this.zoomLabel.text = "Zoom: ";
      this.zoomLabel.textAlignment = TextAlign_Right | TextAlign_VertCenter;

      this.zoomComboBox = new ComboBox( this.previewGroupBox );
      this.zoomComboBox.addItem( "4:1" );
      this.zoomComboBox.addItem( "3:1" );
      this.zoomComboBox.addItem( "2:1" );
      this.zoomComboBox.addItem( "1:1" );
      this.zoomComboBox.addItem( "1:2" );
      this.zoomComboBox.addItem( "Fit to Preview" );
      this.zoomComboBox.currentItem = 5;
      this.zoomComboBox.minWidth = 120;
      this.zoomComboBox.onItemSelected = index =>
      {
         if ( this.showPreviewCheckBox.checked )
            this.updatePreviewZoom();
      };

      this.previewRefreshButton = new PushButton( this.previewGroupBox );
      this.previewRefreshButton.text = "Refresh Preview";
      this.previewRefreshButton.minWidth = 120;
      this.previewRefreshButton.onClick = () =>
      {
         this.refreshPreview();
      };

      this.zoomSizer = new HorizontalSizer;
      this.zoomSizer.margin = 2;
      this.zoomSizer.spacing = 4;
      this.zoomSizer.add( this.zoomLabel );
      this.zoomSizer.add( this.zoomComboBox );
      this.zoomSizer.addSpacing( 12 );
      this.zoomSizer.add( this.previewRefreshButton );
      this.zoomSizer.addStretch();
      this.zoomSizer.visible = false;

      this.previewGroupBox.sizer.add( this.showPreviewCheckBox );
      this.previewGroupBox.sizer.addSpacing( 4 );
      this.previewGroupBox.sizer.add( this.zoomSizer );

      //------------------------------------------------------
      // Action Buttons
      //------------------------------------------------------
      this.apply_Button = new PushButton(this);
      this.apply_Button.text = "Apply";
      this.apply_Button.defaultButton = true;
      this.apply_Button.onClick = () =>
      {
         var starsId = this.starsCombo.itemText(this.starsCombo.currentItem);
         var starlessId = this.starlessCombo.itemText(this.starlessCombo.currentItem);

         if (starsId === starlessId) {
             new MessageBox("The 'Stars' and 'Starless' image selections must be different.", "Error", StdIcon_Error, StdButton_Ok).execute();
             return;
         }

         var targetView = View.viewById(starsId);
         if (targetView.isNull) {
             new MessageBox("Could not locate the target image.", "Error", StdIcon_Error,StdButton_Ok).execute();
             return;
         }

         var PM = new PixelMath;
         var mathStrength = 0.51 - (this.uiStrength * 0.51);

         PM.expression = buildExpression(mathStrength, starlessId, null);
         PM.useSingleExpression = true;
         PM.truncate = true;
         PM.truncateLower = 0;
         PM.truncateUpper = 1;

         if (this.createNewCheckBox.checked) {
             let src = targetView.image;
             let newWindowName = starsId + "_StarReduced";
             let newWindow = new ImageWindow(
                 src.width,
                 src.height,
                 src.numberOfChannels,
                 src.bitsPerSample,
                 src.isReal,
                 src.isColor,
                 newWindowName
             );
             newWindow.mainView.beginProcess();
             newWindow.mainView.image.assign(src);
             newWindow.mainView.endProcess();

             Console.enabled = false;
             try {
                PM.executeOn(newWindow.mainView);
             } finally {
                Console.enabled = true;
             }
             newWindow.show();
             newWindow.zoomToFit();
         } else {
             PM.createNewImage = false;
             Console.enabled = false;
             try {
                PM.executeOn(targetView);
             } finally {
                Console.enabled = true;
             }
         }
      };

      this.undo_Button = new PushButton(this);
      this.undo_Button.text = "Undo";
      this.undo_Button.toolTip = "This button works only when replacing target image.";
      this.undo_Button.onClick = () =>
      {
         var starsId = this.starsCombo.itemText(this.starsCombo.currentItem);
         var targetView = View.viewById(starsId);

         if (!targetView.isNull && targetView.window) {
             targetView.window.undo();
         }
      };

      this.close_Button = new PushButton(this);
      this.close_Button.text = "Close";
      this.close_Button.onClick = () =>
      {
         this.ok();
      };

      //------------------------------------------------------
      // Embedded Preview Component
      //------------------------------------------------------
      this.previewControl = new ScrollControl( this );
      this.previewControl.setMinWidth( 650 );
      this.previewControl.setMinHeight( 650 );
      this.previewControl.visible = false;

      this.onPreviewWheelZoom = ( delta, x, y, modifiers ) =>
      {
         if ( !this.showPreviewCheckBox.checked ) return;

         let i = this.zoomComboBox.currentItem;

         if ( delta > 0 )
            i = Math.max( 0, i - 1 );
         else if ( delta < 0 )
            i = Math.min( this.zoomComboBox.numberOfItems - 1, i + 1 );

         if ( i != this.zoomComboBox.currentItem )
         {
            this.zoomComboBox.currentItem = i;
            this.updatePreviewZoom();
         }
      };

      //------------------------------------------------------
      // Layout Initialization
      //------------------------------------------------------
      var starsSizer = new HorizontalSizer;
      starsSizer.spacing = 6;
      starsSizer.add(this.starsLabel);
      starsSizer.add(this.starsCombo, 100);

      var starSizer = new HorizontalSizer;
      starSizer.spacing = 6;
      starSizer.add(this.starlessLabel);
      starSizer.add(this.starlessCombo, 100);

      var sliderSizer = new HorizontalSizer;
      sliderSizer.spacing = 6;
      sliderSizer.add(this.sliderLabel);
      sliderSizer.add(this.slider, 100);
      sliderSizer.add(this.valueEdit);

      var buttonSizer = new HorizontalSizer;
      buttonSizer.add(this.apply_Button);
      buttonSizer.addSpacing(6);
      buttonSizer.add(this.undo_Button);
      buttonSizer.addSpacing(6);
      buttonSizer.add(this.close_Button);
      buttonSizer.addStretch();

      this.leftSizer = new VerticalSizer;
      this.leftSizer.margin = 12;
      this.leftSizer.spacing = 8;

      this.leftSizer.add(this.titleLabel);
      this.leftSizer.addSpacing(4);
      this.leftSizer.add(this.descBox);
      this.leftSizer.addSpacing(8);

      this.leftSizer.add(this.guideBox);
      this.leftSizer.addSpacing(4);
      this.leftSizer.add(starsSizer);
      this.leftSizer.add(starSizer);
      this.leftSizer.addSpacing(6);
      this.leftSizer.add(sliderSizer);
      this.leftSizer.addSpacing(6);
      this.leftSizer.add(this.outputGroupBox);
      this.leftSizer.addSpacing(6);
      this.leftSizer.add(this.previewGroupBox);
      this.leftSizer.addSpacing(6);
      this.leftSizer.add(buttonSizer);
      this.leftSizer.addStretch();
      this.leftSizer.minWidth = 550;

      this.mainSizer = new HorizontalSizer;
      this.mainSizer.margin = 8;
      this.mainSizer.spacing = 8;
      this.mainSizer.add( this.leftSizer );
      this.mainSizer.add( this.previewControl );

      this.sizer = this.mainSizer;

      this.adjustToContents();
      this.setFixedSize();
   }

   //------------------------------------------------------
   // Preview Core Logic Functions
   //------------------------------------------------------
   refreshPreview()
   {
      if ( !this.showPreviewCheckBox.checked ) return;

      var starsId = this.starsCombo.itemText(this.starsCombo.currentItem);
      var starlessId = this.starlessCombo.itemText(this.starlessCombo.currentItem);

      if (starsId === starlessId || !starsId || !starlessId) return;

      this.buildPreviewBaseImage(starsId, starlessId);
      this.updatePreviewZoom();
   }

   buildPreviewBaseImage(starsId, starlessId)
   {
      let targetView = View.viewById(starsId);
      if (targetView.isNull) return;

      let src = targetView.image;

      let window = new ImageWindow(
         src.width,
         src.height,
         src.numberOfChannels,
         src.bitsPerSample,
         src.isReal,
         src.isColor
      );

      window.mainView.beginProcess();
      window.mainView.image.assign( src );
      window.mainView.endProcess();

      let PM = new PixelMath;
      var mathStrength = 0.51 - (this.uiStrength * 0.51);

      PM.expression = buildExpression(mathStrength, starlessId, null);
      PM.useSingleExpression = true;
      PM.createNewImage = false;
      PM.truncate = true;
      PM.truncateLower = 0;
      PM.truncateUpper = 1;

      Console.enabled = false;
      try {
         PM.executeOn( window.mainView );
      } finally {
         Console.enabled = true;
      }

      this.previewBaseImage = new Image( window.mainView.image );
      window.forceClose();
   }

   updatePreviewZoom()
   {
      if ( this.previewBaseImage == null ) return;

      let selectedImage = this.previewBaseImage;

      let window = new ImageWindow(
         selectedImage.width,
         selectedImage.height,
         selectedImage.numberOfChannels,
         selectedImage.bitsPerSample,
         selectedImage.isReal,
         selectedImage.isColor
      );

      window.mainView.beginProcess();
      window.mainView.image.assign( selectedImage );
      window.mainView.endProcess();

      let P = new IntegerResample;

      switch ( this.zoomComboBox.currentItem )
      {
      case 0:
         P.zoomFactor = 4; // 4:1
         break;
      case 1:
         P.zoomFactor = 3; // 3:1
         break;
      case 2:
         P.zoomFactor = 2; // 2:1
         break;
      case 3:
         P.zoomFactor = 1; // 1:1
         break;
      case 4:
         P.zoomFactor = -2; // 1:2
         break;
      case 5: // Fit to Preview
         {
            let previewWidth = Math.max( this.previewControl.width, 1 );
            let widthScale = Math.floor( selectedImage.width / previewWidth );
            P.zoomFactor = -Math.max( widthScale, 1 );
         }
         break;
      default:
         P.zoomFactor = 1;
         break;
      }

      P.executeOn( window.mainView );

      let resizedImage = new Image( window.mainView.image );
      window.forceClose();

      this.previewControl.doUpdateImage( resizedImage );
   }
};

//---------------------------------------------------------
// Main
//---------------------------------------------------------
function main()
{
   if ( ImageWindow.windows.length < 2 )
   {
      new MessageBox(
         "You need to have at least two images open (a star image and a starless image).",
         "Error",
         StdIcon_Error,
         StdButton_Ok
      ).execute();
      return;
   }

   var dlg = new StarReductionDialog();
   dlg.execute();
}

main();
